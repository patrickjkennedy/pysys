# Pysys - System Information

This package was created as part of Practical 1 of UCD's Software Engineering course, COMP30830.
It returns information (OS, total memory, IP address etc.) about the system it is run on.
