import platform
import multiprocessing
import socket
from psutil import virtual_memory


def info():
    """ This function prints out system information such as the machine's name, OS name and version etc. """

    print("----- System Information -----")
    print("Machine Name: ", platform.node())
    print("Operating System Name: ", platform.system())
    print("Operating System Version: ", platform.release())
    print("Number of CPUs: ", multiprocessing.cpu_count())

    # Display total memory in GB
    total_memory = virtual_memory().total >> 30
    print("Total Memory (GB): ", total_memory)

    host_ip = socket.gethostbyname(socket.gethostname())
    print("IP Address: ", host_ip)



